# Theme Detector calculators package
