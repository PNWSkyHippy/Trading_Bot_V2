# Uptrend Analyzer - Calculator modules
